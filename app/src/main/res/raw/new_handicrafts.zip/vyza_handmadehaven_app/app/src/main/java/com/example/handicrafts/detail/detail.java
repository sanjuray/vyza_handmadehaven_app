package com.example.handicrafts.detail;

public class detail {
}
